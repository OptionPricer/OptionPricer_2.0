package model;

/**
 * @author Sky
 * Enum for option right.
 */
public enum  OptionRight {
    PUT,CALL;
}
