package model;

/**
 * @author Sky
 * Enum for model.Option style.
 */
public enum  OptionStyle {
    AMERICAN, ASIAN, EUROPEAN;
}
